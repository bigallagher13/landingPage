i began by building the navbar
this loop creates an li element for each section added to the page

i then added helper functions to add active classes to the correct section elements when they are in the viewport

this goes with the scroll event i created to navigate through the page
