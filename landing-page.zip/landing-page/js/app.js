/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
*/

/**
 * Define Global Variables
 *
*/



/**
 * End Global Variables
 * Start Helper Functions
 *
*/


/**
 * End Helper Functions
 * Begin Main Functions
 *
*/

// build the nav
const navlist = document.querySelector("#navbar__list");

const listelement1 = document.createElement('li');
const listelement2 = document.createElement('li');
const listelement3 = document.createElement('li');
const listelement4 = document.createElement('li');

listelement1.innerHTML = '<a class="menu__link" href="#section1">Section 1</a>';
listelement2.innerHTML = '<a class="menu__link" href="#section2">Section 2</a>';
listelement3.innerHTML = '<a class="menu__link" href="#section3">Section 3</a>';
listelement4.innerHTML = '<a class="menu__link" href="#section4">Section 4</a>';

navlist.appendChild(listelement1);
navlist.appendChild(listelement2);
navlist.appendChild(listelement3);
navlist.appendChild(listelement4);



// Add class 'active' to section when near top of viewport

const actives = navlist.getElementsByClassName("menu__link");
for (let i = 0; i < actives.length; i++) {
  actives[i].addEventListener("click", function() {
    const current = document.getElementsByClassName("active");

    if (current.length > 0) {
      current[0].className = current[0].className.replace(" active", "");
    }
    this.className += " active";
  })
}


// Scroll to anchor ID using scrollTO event
/*function smoothScroll(target,duration){
  var target = document.querySelector(target);
  var targetPosition = target.getBoundingClientRect();
  var startPosition = window.pageYOffset;
  var distance = targetPosition - startPosition;
  var startTime = null;

  function animation(currentTime){
    if(startTime === null) startTime = currentTime;
    var timeElapsed = currentTime - startTime;
    var run = ease(timeElapsed, startPosition, distance, duration);
    window.scrollTo(0, run);
    if(timeElapsed < duration) requestAnimationFrame(animation);
  }

  function ease(t, b, c, d){
    t /= d / 2;
    if (t < 1) return c / 2 * t * t + b;
    t--;
    return -c / 2 * (t-2) - 1 + b;
  }
  requestAnimationFrame(animation);
}

listelement1.addEventListener('click', function(){
  smoothScroll('#section1', 1000);
}) */
/**
 * End Main Functions

 event listener onscroll to highlight content i think
 when scroll highlights section content (change  background color)

 have navbar scroll

 * Begin Events
 *
*/

// Build menu

// Scroll to section on link click



// Set sections as active
