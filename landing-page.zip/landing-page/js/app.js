/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
*/

/**
 * Define Global Variables
 *
*/


/**
 * End Global Variables
 * Start Helper Functions
 *
*/


/**
 * End Helper Functions
 * Begin Main Functions
 *
*/

// build the nav
const navlist = document.querySelector('#navbar__list');

const listelement1 = document.createElement('li');
const listelement2 = document.createElement('li');
const listelement3 = document.createElement('li');

listelement1.innerHTML = '<a href="#section1">Section 1</a>';
listelement2.innerHTML = '<a href="#section2">Section 2</a>';
listelement3.innerHTML = '<a href="#section3">Section 3</a>';

navlist.appendChild(listelement1);
navlist.appendChild(listelement2);
navlist.appendChild(listelement3);



// Add class 'active' to section when near top of viewport


// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions

 nav bar

 when in section, section gets highlighted in navigation
 event listener on scroll
 when scroll highlights section content (change  background color)

 have navbar scroll
 
 * Begin Events
 *
*/

// Build menu

// Scroll to section on link click

// Set sections as active
